TEB0701 System controller update
Revision 05 for TE0701-03/04/05(No S4 DIP switches) and TE0705-06: CC701_RE05.jed
General Firmware description:https://wiki.trenz-electronic.de/display/PD/SC-CPLD-Firmware
CPLD description:https://wiki.trenz-electronic.de/display/PD/TE0701+CPLD
